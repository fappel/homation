package com.codeaffine.machine.status.reporter;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.codahale.metrics.annotation.Timed;
import com.codeaffine.machine.status.reporter.Win32IdleTime.MachineStatus;

@Path("/machine-status")
@Produces(MediaType.APPLICATION_JSON)
public class MachineStatusResource {

  @GET
  @Timed
  public MachineStatus getMachineStatus() {
    return Win32IdleTime.getMachineStatus();
  }
}