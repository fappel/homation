package com.codeaffine.machine.status.reporter;

import static com.codeaffine.machine.status.reporter.Win32IdleTime.getIdleTimeMillisWin32;
import static java.util.concurrent.Executors.newSingleThreadExecutor;
import static java.util.stream.Collectors.toList;

import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.io.IOException;
import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.util.Scanner;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.dropwizard.Application;
import io.dropwizard.setup.Environment;

public class CurrentStatusNotifier extends Application<MachineStatusReporterConfiguration> {

  @Override
  public void run( MachineStatusReporterConfiguration configuration, Environment environment ) {
    setDefaultAuthentication( configuration.getUserName(), configuration.getPassWord() );
    newSingleThreadExecutor().execute( () -> runNotifications( configuration ) );
  }

  private static void setDefaultAuthentication( String userName, String password ) {
    Authenticator.setDefault( new Authenticator() {
      @Override
      protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication( userName, password.toCharArray() );
      }
    } );
  }

  private static void runNotifications( MachineStatusReporterConfiguration configuration ) {
    while( true ) {
      runNotification( configuration, computeIdleTime() );
      sleep( configuration );
    }
  }

  private static int computeIdleTime() {
    if( isDocked() ) {
      return getIdleTimeMillisWin32() / 1000;
    }
    return Integer.MAX_VALUE;
  }

  private static boolean isDocked() {
    GraphicsEnvironment environment = GraphicsEnvironment.getLocalGraphicsEnvironment();
    GraphicsDevice[] devices = environment.getScreenDevices();
    return !Stream.of( devices )
      .filter( device -> isDellMonitor( device ) )
      .collect( toList() )
      .isEmpty();
  }

  private static boolean isDellMonitor( GraphicsDevice device ) {
    return device.getType() == GraphicsDevice.TYPE_RASTER_SCREEN && device.getDisplayMode().getWidth() == 1920;
  }
  
  private static void runNotification( MachineStatusReporterConfiguration configuration, int idleSeconds ) {
    URL url = createURL( configuration, idleSeconds );
    try( Scanner scanner = new Scanner( url.openStream() ) ) {
      scanner.useDelimiter( "\\A" ).next();
    } catch( IOException e ) {
      Logger logger = LoggerFactory.getLogger( CurrentStatusNotifier.class.getName() );
      logger.warn( "Status cannot be pushed to openhab server.", e );
    }
  }

  private static URL createURL( MachineStatusReporterConfiguration configuration, int idleSeconds ) {
    try {
      return new URL( "http://" + configuration.getOpenhabAddress() + "/CMD?computerIdleTime=" + idleSeconds );
    } catch( MalformedURLException e ) {
      throw new IllegalArgumentException( "Openhab server address is not valid.", e );
    }
  }
  
  private static void sleep( MachineStatusReporterConfiguration configuration ) {
    try {
      Thread.sleep( configuration.getNotificationInterval() );
    } catch( InterruptedException shouldNotHappen ) {
      throw new IllegalStateException( shouldNotHappen );
    }
  }
}