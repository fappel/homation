package com.codeaffine.machine.status.reporter;

import io.dropwizard.Application;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;

public class MachineStatusReporter extends Application<MachineStatusReporterConfiguration> {

  public static void main( String[] args ) throws Exception {
    new MachineStatusReporter().run( args );
  }

  @Override
  public void run( MachineStatusReporterConfiguration configuration, Environment environment ) {
    environment.jersey().register( new MachineStatusResource() );
    new CurrentStatusNotifier().run( configuration, environment );
  }
  
  @Override
  public String getName() {
    return "Machine State Reporter";
  }
  
  @Override
  public void initialize( Bootstrap<MachineStatusReporterConfiguration> bootstrap ) {
    // nothing to do yet
  }
}