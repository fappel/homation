package com.codeaffine.machine.status.reporter;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.dropwizard.Configuration;

public class MachineStatusReporterConfiguration extends Configuration {

  @NotEmpty
  private String userName;
  @NotEmpty
  private String passWord;
  @NotEmpty
  private String openhabAddress;
  private long notificationInterval;
  
  @JsonProperty
  public void setUserName( String userName ) {
    this.userName = userName;
  }
  
  @JsonProperty
  public void setPassWord( String passWord ) {
    this.passWord = passWord;
  }

  @JsonProperty
  public String getUserName() {
    return userName;
  }

  @JsonProperty
  public String getPassWord() {
    return passWord;
  }

  public void setOpenhabAddress( String openhabAddress ) {
    this.openhabAddress = openhabAddress;
  }
  
  @JsonProperty
  public String getOpenhabAddress() {
    return openhabAddress;
  }

  @JsonProperty
  public long getNotificationInterval() {
    return notificationInterval;
  }

  @JsonProperty
  public void setNotificationInterval( long notificationInterval ) {
    this.notificationInterval = notificationInterval;
  }
}